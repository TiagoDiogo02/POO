class Oldie extends Telemovel {
    public Oldie(int numero, String modoFuncionamento) {
        super(numero, modoFuncionamento);
    }
}